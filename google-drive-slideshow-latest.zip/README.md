# Family Photo Slideshow

Web app trình chiếu ảnh Google Drive trên Android TV box + thiệp sự kiện + cấu hình cloud.

## Checklist nâng cấp

1. Tạo tab **Settings** và **Events** trên Google Sheet (xem cấu trúc dưới).
2. Cập nhật **Code.gs** trong Apps Script (giữ đúng SHEET_ID của bạn) → Deploy → New version.
3. Script Properties: SETTINGS_PIN (tuỳ chọn), TELEGRAM_TOKEN, TELEGRAM_CHAT_ID.
4. Push code lên GitHub Pages (giữ nguyên js/config.js GAS_URL).
5. Reload box (?v=21 hoặc nút Tải lại bản mới nhất).

## Sheet

### Config
- api_key | (Google API key)

### Sources
- name | link | enabled | order

### Settings (cột key | value)
- duration, transition, effect, fit, idle, shuffle, resume
- event_duration (giây hiện thiệp, mặc định 60)
- event_interval_minutes (phút giữa hai lần thiệp, mặc định 60)

### Events
template | year | month | day | title_name | pair_left | pair_right | image_link | enabled | order

- template: birthday hoặc wedding
- birthday: dùng title_name (tên), hiện Lần thứ N
- wedding: pair_left / pair_right (Ba / Mẹ), hiện Kỷ niệm N năm ngày cưới
- N = năm hiện tại - year (chỉ đúng ngày)

## Luồng chính
- Load trang / Cập nhật / reboot → GAS trả settings + sources + events
- Điện thoại: Lưu lên cloud → ghi tab Settings
- Box poll mỗi 2 phút → tự áp dụng settings mới
- Thiệp sự kiện: đúng ngày; sau ảnh đầu đếm theo phút; hiện event_duration giây

## Menu
- TV: giữ đủ chức năng
- Mobile: Lưu / Cập nhật ghim dưới panel; cuộn touch
